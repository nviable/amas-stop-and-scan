---
name: Amito Learning System
colors:
  surface: '#fef7ff'
  surface-dim: '#e1d4fd'
  surface-bright: '#fef7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f1ff'
  surface-container: '#f3eaff'
  surface-container-high: '#eee4ff'
  surface-container-highest: '#e9ddff'
  on-surface: '#1f1635'
  on-surface-variant: '#434655'
  inverse-surface: '#342b4b'
  inverse-on-surface: '#f6edff'
  outline: '#737687'
  outline-variant: '#c3c5d8'
  surface-tint: '#0050e1'
  primary: '#004cd7'
  on-primary: '#ffffff'
  primary-container: '#2665fd'
  on-primary-container: '#f9f7ff'
  inverse-primary: '#b5c4ff'
  secondary: '#845400'
  on-secondary: '#ffffff'
  secondary-container: '#feae39'
  on-secondary-container: '#6d4400'
  tertiary: '#a03600'
  on-tertiary: '#ffffff'
  tertiary-container: '#c94600'
  on-tertiary-container: '#fff7f4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b5c4ff'
  on-primary-fixed: '#00164d'
  on-primary-fixed-variant: '#003cad'
  secondary-fixed: '#ffddb6'
  secondary-fixed-dim: '#ffb95a'
  on-secondary-fixed: '#2a1800'
  on-secondary-fixed-variant: '#643f00'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#802a00'
  background: '#fef7ff'
  on-background: '#1f1635'
  surface-variant: '#e9ddff'
  background-paper: '#fbf8f2'
  surface-cream: '#f6f0e4'
  lilac-accent: '#b197fc'
  stop-red: '#ef4a6b'
  source-cyan: '#22b8cf'
  content-green: '#37b24d'
  reflect-orange: '#ff922b'
  welcome-blue: '#4dabf7'
typography:
  display-xl:
    fontFamily: Outfit
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  handwritten-lg:
    fontFamily: Gochi Hand
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-max: 1152px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
---

## Brand & Style

This design system is built on a **warm, tactile journal philosophy** designed to make educational content feel approachable and human-centric. It departs from sterile, high-tech aesthetics in favor of a "sketchbook" atmosphere that reduces cognitive load and encourages curiosity.

The visual narrative centers around **Amito**, a friendly mascot who serves as a guide through the sensemaking framework. The style is **Modern-Tactile**: it combines clean, high-legibility digital interfaces with soft, organic textures, rounded geometry, and "glowing" interactive states that mimic auras. The goal is to create a safe, low-glare environment where users feel empowered to slow down and reflect.

**Key Stylistic Pillars:**
- **Paper-First:** Use off-white and cream backgrounds to simulate physical paper.
- **Friendly Geometry:** Avoid sharp corners entirely; utilize generous radii to maintain a soft, welcoming feel.
- **Mascot Integration:** Use Amito’s various poses as contextual anchors for information, often paired with speech bubble containers.

## Colors

The palette is strategically divided into grounding neutrals and framework-driven vibrants.

- **Foundational Neutrals:** The core interface uses **Background Paper** for main layouts and **Surface Cream** for secondary panels, creating a "warm journal" feel. **Deep Navy Ink** (#241b3a) serves as the primary high-contrast color for text and borders, replacing harsh blacks.
- **Framework Glows:** Specific colors are mapped to the STOP&SCAN steps. Use these strictly for their respective logical states (e.g., **Stop Red** for pauses, **Content Green** for analysis).
- **Primary Action:** The **Primary Blue** (#2665fd) is reserved for high-importance call-to-actions, while **Lilac Accent** is used for secondary interactive highlights and navigation themes.

## Typography

The hierarchy uses a tri-font system to balance modern precision with a personal touch.

1.  **Display & Headings (Outfit):** Geometric and professional, used for all structural titles. Tighten tracking on larger sizes to create a cohesive, "locked" feel.
2.  **Body (Nunito Sans):** Rounded and humanist, selected for its extreme readability in long educational blocks. Use a relaxed line height (1.5x - 1.6x) to ensure text-heavy sections remain inviting.
3.  **Annotations (Gochi Hand/Handwritten):** Use sparingly for "post-it" style notes, quote blocks, or journal reflection headers to reinforce the tactile sketchbook theme.

On mobile devices, scale `display-xl` down to `display-lg` sizing to ensure accessibility and fit.

## Layout & Spacing

This design system employs a **Fluid-Fixed hybrid model**. Content is contained within a maximum width of 1152px for optimal readability, but layout blocks are designed to be full-width responsive with deep vertical padding.

**Layout Principles:**
- **Breatheability:** Utilize generous vertical spacing (`xl` to `xxl`) between sections to prevent "educational fatigue."
- **Grid Density:** On desktop, use a 12-column grid. For framework-specific views, a 5-column layout is permissible. 
- **Responsive Reflow:** Layouts must collapse to a single column on mobile. Interactive touch targets (buttons/cards) must maintain at least 48px height.
- **Margins:** Desktop margins are set to 40px to provide a framing effect, while mobile margins compress to 20px to maximize screen real estate.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Glows** rather than aggressive shadows.

- **Surface Tiering:** Use the `background-paper` as the base. Cards and containers use pure `#FFFFFF` or `surface-cream` to visually lift from the page.
- **Hairline Borders:** Instead of heavy shadows, use a 1px border in `Navy Ink` with 10% opacity (`#241b3a1a`) to define card boundaries.
- **Soft Glows:** Important interactive elements or mascot-related backgrounds use a diffused, low-opacity color tint (the "aura" effect) instead of a standard drop shadow.
- **Active States:** Use a subtle `scale(0.98)` transform on click to provide tactile feedback without adding visual clutter.

## Shapes

The shape language is consistently **Rounded**, reinforcing the friendly and safe brand personality.

- **Base Radius:** 8px (`rounded-md`) is the standard for inputs and smaller buttons.
- **Container Radius:** Cards and large panels use 24px (`rounded-3xl`) to create a soft, friendly silhouette.
- **Pill Shapes:** Primary buttons and navigation links use `rounded-full` for maximum approachability.
- **Speech Bubbles:** A unique shape role where 16px corners are used, but the top-left or top-right corner is left sharp (0px) to indicate the "tail" pointing toward Amito.

## Components

### Buttons
- **Primary:** Pill-shaped, solid `Navy Ink` with white text. Includes a soft, dark-tinted shadow.
- **Secondary:** Pill-shaped, solid `Lilac Accent` or ghost style with a 2px `Navy Ink` border at 15% opacity.
- **Interactive States:** Hover effects should involve a subtle brightness increase (105%) or a soft background shift, avoiding harsh color changes.

### Cards & Speech Bubbles
- **Standard Card:** White background, 24px rounded corners, hairline border, and a "shadow-soft" (low opacity navy tint).
- **Amito Speech Bubble:** 16px rounded corners with one corner sharp. Always background-filled with white to ensure readability against warm-paper backgrounds.

### Chips & Tags
- Used for framework steps. Use the step-specific color (e.g., `Stop-Red`) as a light background tint (15% opacity) with a solid border and matching text color.

### Inputs & Selectors
- **Input Fields:** 1px `Navy Ink` border (10% opacity) with `surface-cream` background. 8px rounded corners.
- **Quiz Selectors:** Large interactive blocks with 16px corners. Selection state uses `Lilac-Accent` borders (2px) and a light lilac background tint.

### Lists
- Use horizontal dividers in `Navy Ink` at 5% opacity. Bullet points are replaced with custom organic icons or small Amito-themed dots.